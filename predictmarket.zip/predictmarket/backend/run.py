"""Entry point: `python3 run.py` starts the app on http://localhost:8000
(serves both the API under /api/* and the frontend)."""
from app.server import app

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
