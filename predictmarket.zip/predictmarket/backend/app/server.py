import datetime
import os
from functools import wraps

from flask import Flask, request, jsonify, g, send_from_directory

from . import db, amm
from .security import hash_password, verify_password, new_token

FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "frontend")

app = Flask(__name__, static_folder=None)
db.init_db(app)


def seed_admin():
    import sqlite3
    conn = sqlite3.connect(db.DB_PATH)
    conn.row_factory = sqlite3.Row
    existing = conn.execute("SELECT id FROM users WHERE username = 'admin'").fetchone()
    if not existing:
        pw_hash = hash_password("admin123")
        conn.execute(
            "INSERT INTO users (username, password_hash, balance, is_admin) VALUES ('admin', ?, ?, 1)",
            (pw_hash, db.STARTING_BALANCE),
        )
        conn.commit()
        print("Seeded default admin user -> username: admin / password: admin123 (CHANGE THIS BEFORE ANY REAL USE)")
    conn.close()


seed_admin()


def now_iso():
    return datetime.datetime.utcnow().isoformat()


# ---------- auth helpers ----------

def get_current_user():
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None
    token = auth[len("Bearer "):].strip()
    conn = db.get_db()
    row = conn.execute(
        "SELECT users.* FROM sessions JOIN users ON users.id = sessions.user_id WHERE sessions.token = ?",
        (token,),
    ).fetchone()
    return row


def require_auth(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if user is None:
            return jsonify({"detail": "Not authenticated"}), 401
        g.user = user
        return f(*args, **kwargs)
    return wrapper


def require_admin(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if user is None:
            return jsonify({"detail": "Not authenticated"}), 401
        if not user["is_admin"]:
            return jsonify({"detail": "Admin access required"}), 403
        g.user = user
        return f(*args, **kwargs)
    return wrapper


# ---------- serializers ----------

def market_price(m):
    if m["status"] == "resolved":
        return 1.0 if m["resolved_outcome"] == "YES" else 0.0
    return amm.price_yes(m["q_yes"], m["q_no"], m["b"])


def serialize_market(m, with_description=False, with_history=False, conn=None):
    out = {
        "id": m["id"],
        "question": m["question"],
        "category": m["category"],
        "status": m["status"],
        "resolved_outcome": m["resolved_outcome"],
        "price_yes": round(market_price(m), 4),
        "created_at": m["created_at"],
        "close_time": m["close_time"],
    }
    if with_description:
        out["description"] = m["description"]
    if with_history and conn is not None:
        rows = conn.execute(
            "SELECT price_yes, created_at FROM price_points WHERE market_id = ? ORDER BY created_at ASC",
            (m["id"],),
        ).fetchall()
        out["price_history"] = [{"t": r["created_at"], "price": r["price_yes"]} for r in rows]
    return out


# ---------- auth routes ----------

@app.post("/api/signup")
def signup():
    data = request.get_json(force=True, silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""
    if len(username) < 3 or len(username) > 32:
        return jsonify({"detail": "Username must be 3-32 characters"}), 400
    if len(password) < 6:
        return jsonify({"detail": "Password must be at least 6 characters"}), 400

    conn = db.get_db()
    existing = conn.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
    if existing:
        return jsonify({"detail": "Username already taken"}), 400

    pw_hash = hash_password(password)
    cur = conn.execute(
        "INSERT INTO users (username, password_hash, balance, is_admin) VALUES (?, ?, ?, 0)",
        (username, pw_hash, db.STARTING_BALANCE),
    )
    user_id = cur.lastrowid
    conn.execute(
        "INSERT INTO transactions (user_id, type, amount, balance_after) VALUES (?, 'signup_bonus', ?, ?)",
        (user_id, db.STARTING_BALANCE, db.STARTING_BALANCE),
    )
    token = new_token()
    conn.execute("INSERT INTO sessions (token, user_id) VALUES (?, ?)", (token, user_id))
    conn.commit()

    return jsonify({"token": token, "username": username, "balance": db.STARTING_BALANCE, "is_admin": False})


@app.post("/api/login")
def login():
    data = request.get_json(force=True, silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    conn = db.get_db()
    user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    if not user or not verify_password(password, user["password_hash"]):
        return jsonify({"detail": "Invalid username or password"}), 401

    token = new_token()
    conn.execute("INSERT INTO sessions (token, user_id) VALUES (?, ?)", (token, user["id"]))
    conn.commit()
    return jsonify({
        "token": token, "username": user["username"],
        "balance": user["balance"], "is_admin": bool(user["is_admin"]),
    })


@app.get("/api/me")
@require_auth
def me():
    u = g.user
    return jsonify({"username": u["username"], "balance": u["balance"], "is_admin": bool(u["is_admin"])})


# ---------- market routes ----------

@app.get("/api/markets")
def list_markets():
    conn = db.get_db()
    rows = conn.execute("SELECT * FROM markets ORDER BY created_at DESC").fetchall()
    return jsonify([serialize_market(m) for m in rows])


@app.post("/api/markets")
@require_admin
def create_market():
    data = request.get_json(force=True, silent=True) or {}
    question = (data.get("question") or "").strip()
    if len(question) < 5:
        return jsonify({"detail": "Question must be at least 5 characters"}), 400
    description = data.get("description") or ""
    category = data.get("category") or "General"
    liquidity_b = float(data.get("liquidity_b") or db.DEFAULT_LIQUIDITY_B)
    if liquidity_b <= 0:
        return jsonify({"detail": "liquidity_b must be positive"}), 400
    close_time = data.get("close_time")

    conn = db.get_db()
    cur = conn.execute(
        "INSERT INTO markets (question, description, category, creator_id, b, q_yes, q_no, close_time) "
        "VALUES (?, ?, ?, ?, ?, 0, 0, ?)",
        (question, description, category, g.user["id"], liquidity_b, close_time),
    )
    market_id = cur.lastrowid
    conn.execute(
        "INSERT INTO price_points (market_id, price_yes) VALUES (?, 0.5)", (market_id,)
    )
    conn.commit()
    m = conn.execute("SELECT * FROM markets WHERE id = ?", (market_id,)).fetchone()
    return jsonify(serialize_market(m))


@app.get("/api/markets/<int:market_id>")
def get_market(market_id):
    conn = db.get_db()
    m = conn.execute("SELECT * FROM markets WHERE id = ?", (market_id,)).fetchone()
    if not m:
        return jsonify({"detail": "Market not found"}), 404
    return jsonify(serialize_market(m, with_description=True, with_history=True, conn=conn))


@app.post("/api/markets/<int:market_id>/trade")
@require_auth
def trade(market_id):
    data = request.get_json(force=True, silent=True) or {}
    outcome = data.get("outcome")
    try:
        shares = float(data.get("shares"))
    except (TypeError, ValueError):
        return jsonify({"detail": "shares must be a number"}), 400

    if outcome not in ("YES", "NO"):
        return jsonify({"detail": "outcome must be YES or NO"}), 400
    if shares == 0:
        return jsonify({"detail": "shares cannot be 0"}), 400

    conn = db.get_db()
    m = conn.execute("SELECT * FROM markets WHERE id = ?", (market_id,)).fetchone()
    if not m:
        return jsonify({"detail": "Market not found"}), 404
    if m["status"] != "open":
        return jsonify({"detail": "Market is not open for trading"}), 400

    user = conn.execute("SELECT * FROM users WHERE id = ?", (g.user["id"],)).fetchone()
    pos = conn.execute(
        "SELECT * FROM positions WHERE user_id = ? AND market_id = ?", (user["id"], market_id)
    ).fetchone()
    if pos is None:
        conn.execute(
            "INSERT INTO positions (user_id, market_id, shares_yes, shares_no) VALUES (?, ?, 0, 0)",
            (user["id"], market_id),
        )
        pos = conn.execute(
            "SELECT * FROM positions WHERE user_id = ? AND market_id = ?", (user["id"], market_id)
        ).fetchone()

    held = pos["shares_yes"] if outcome == "YES" else pos["shares_no"]
    if shares < 0 and abs(shares) > held + 1e-9:
        return jsonify({"detail": "Cannot sell more shares than you hold"}), 400

    cost = amm.trade_cost(m["q_yes"], m["q_no"], m["b"], outcome, shares)
    if cost > 0 and cost > user["balance"] + 1e-9:
        return jsonify({"detail": "Insufficient balance for this trade"}), 400

    new_q_yes = m["q_yes"] + shares if outcome == "YES" else m["q_yes"]
    new_q_no = m["q_no"] + shares if outcome == "NO" else m["q_no"]
    new_balance = user["balance"] - cost
    new_shares_yes = pos["shares_yes"] + (shares if outcome == "YES" else 0)
    new_shares_no = pos["shares_no"] + (shares if outcome == "NO" else 0)
    new_price = amm.price_yes(new_q_yes, new_q_no, m["b"])

    conn.execute("UPDATE markets SET q_yes = ?, q_no = ? WHERE id = ?", (new_q_yes, new_q_no, market_id))
    conn.execute("UPDATE users SET balance = ? WHERE id = ?", (new_balance, user["id"]))
    conn.execute(
        "UPDATE positions SET shares_yes = ?, shares_no = ? WHERE id = ?",
        (new_shares_yes, new_shares_no, pos["id"]),
    )
    conn.execute(
        "INSERT INTO transactions (user_id, market_id, type, outcome, shares, amount, balance_after) "
        "VALUES (?, ?, 'trade', ?, ?, ?, ?)",
        (user["id"], market_id, outcome, shares, -cost, new_balance),
    )
    conn.execute("INSERT INTO price_points (market_id, price_yes) VALUES (?, ?)", (market_id, new_price))
    conn.commit()

    return jsonify({
        "balance": new_balance, "cost": cost, "price_yes": round(new_price, 4),
        "position_shares_yes": new_shares_yes, "position_shares_no": new_shares_no,
    })


@app.post("/api/markets/<int:market_id>/resolve")
@require_admin
def resolve_market(market_id):
    data = request.get_json(force=True, silent=True) or {}
    outcome = data.get("outcome")
    if outcome not in ("YES", "NO"):
        return jsonify({"detail": "outcome must be YES or NO"}), 400

    conn = db.get_db()
    m = conn.execute("SELECT * FROM markets WHERE id = ?", (market_id,)).fetchone()
    if not m:
        return jsonify({"detail": "Market not found"}), 404
    if m["status"] == "resolved":
        return jsonify({"detail": "Market already resolved"}), 400

    conn.execute(
        "UPDATE markets SET status = 'resolved', resolved_outcome = ?, resolved_at = ? WHERE id = ?",
        (outcome, now_iso(), market_id),
    )

    positions = conn.execute("SELECT * FROM positions WHERE market_id = ?", (market_id,)).fetchall()
    for pos in positions:
        winning_shares = pos["shares_yes"] if outcome == "YES" else pos["shares_no"]
        if winning_shares > 1e-9:
            user = conn.execute("SELECT * FROM users WHERE id = ?", (pos["user_id"],)).fetchone()
            new_balance = user["balance"] + winning_shares
            conn.execute("UPDATE users SET balance = ? WHERE id = ?", (new_balance, user["id"]))
            conn.execute(
                "INSERT INTO transactions (user_id, market_id, type, outcome, shares, amount, balance_after) "
                "VALUES (?, ?, 'payout', ?, ?, ?, ?)",
                (user["id"], market_id, outcome, winning_shares, winning_shares, new_balance),
            )
    conn.commit()
    m = conn.execute("SELECT * FROM markets WHERE id = ?", (market_id,)).fetchone()
    return jsonify(serialize_market(m))


@app.get("/api/portfolio")
@require_auth
def portfolio():
    conn = db.get_db()
    rows = conn.execute(
        "SELECT positions.*, markets.question AS q_question, markets.status AS q_status, "
        "markets.q_yes AS q_qyes, markets.q_no AS q_qno, markets.b AS q_b, "
        "markets.resolved_outcome AS q_resolved_outcome "
        "FROM positions JOIN markets ON markets.id = positions.market_id "
        "WHERE positions.user_id = ?",
        (g.user["id"],),
    ).fetchall()
    out = []
    for r in rows:
        if abs(r["shares_yes"]) < 1e-9 and abs(r["shares_no"]) < 1e-9:
            continue
        if r["q_status"] == "resolved":
            price = 1.0 if r["q_resolved_outcome"] == "YES" else 0.0
        else:
            price = amm.price_yes(r["q_qyes"], r["q_qno"], r["q_b"])
        out.append({
            "market_id": r["market_id"], "question": r["q_question"], "status": r["q_status"],
            "price_yes": round(price, 4), "shares_yes": r["shares_yes"], "shares_no": r["shares_no"],
            "resolved_outcome": r["q_resolved_outcome"],
        })
    return jsonify(out)


@app.get("/api/health")
def health():
    return jsonify({"status": "ok"})


# ---------- serve frontend ----------

@app.get("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.get("/<path:path>")
def static_files(path):
    full = os.path.join(FRONTEND_DIR, path)
    if os.path.isfile(full):
        return send_from_directory(FRONTEND_DIR, path)
    return send_from_directory(FRONTEND_DIR, "index.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
