// PredictMarket demo frontend — vanilla JS, no build step, no external dependencies.

const state = {
  token: localStorage.getItem('pm_token') || null,
  user: null, // { username, balance, is_admin }
};

const appEl = document.getElementById('app');
const navEl = document.getElementById('main-nav');
const authAreaEl = document.getElementById('auth-area');

// ---------- API helper ----------

async function api(path, { method = 'GET', body = null, auth = true } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth && state.token) headers['Authorization'] = `Bearer ${state.token}`;
  const res = await fetch(path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : null,
  });
  let data = null;
  try { data = await res.json(); } catch (e) { /* no body */ }
  if (!res.ok) {
    const msg = (data && data.detail) ? data.detail : `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function fmtMoney(n) {
  return '$' + Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtPct(p) {
  return Math.round(p * 100) + '%';
}

function fmtTime(iso) {
  try {
    return new Date(iso + 'Z').toLocaleString();
  } catch (e) { return iso; }
}

// ---------- session bootstrap ----------

async function refreshMe() {
  if (!state.token) { state.user = null; return; }
  try {
    state.user = await api('/api/me');
  } catch (e) {
    state.token = null;
    state.user = null;
    localStorage.removeItem('pm_token');
  }
}

function logout() {
  state.token = null;
  state.user = null;
  localStorage.removeItem('pm_token');
  renderHeader();
  navigate('#/markets');
}

// ---------- header ----------

function renderHeader() {
  const route = location.hash || '#/markets';
  const links = [
    ['#/markets', 'Markets'],
  ];
  if (state.user) links.push(['#/portfolio', 'Portfolio']);
  if (state.user && state.user.is_admin) links.push(['#/admin', 'Admin']);

  navEl.innerHTML = links.map(([href, label]) => {
    const active = route.startsWith(href) ? ' class="active"' : '';
    return `<a href="${href}"${active}>${label}</a>`;
  }).join('');

  if (state.user) {
    authAreaEl.innerHTML = `
      <span class="balance-pill">${fmtMoney(state.user.balance)}</span>
      <span class="muted">${escapeHtml(state.user.username)}</span>
      <button id="logout-btn">Log out</button>
    `;
    document.getElementById('logout-btn').onclick = logout;
  } else {
    authAreaEl.innerHTML = `<a href="#/login" class="btn">Log in / Sign up</a>`;
  }
}

// ---------- router ----------

const routes = [
  { pattern: /^#\/markets$/, handler: renderMarketsList },
  { pattern: /^#\/market\/(\d+)$/, handler: renderMarketDetail },
  { pattern: /^#\/portfolio$/, handler: renderPortfolio, auth: true },
  { pattern: /^#\/admin$/, handler: renderAdmin, admin: true },
  { pattern: /^#\/login$/, handler: renderLogin },
];

async function navigate(hash) {
  if (hash && location.hash !== hash) {
    location.hash = hash;
    return; // will re-trigger via hashchange
  }
  const route = location.hash || '#/markets';
  const match = routes.find(r => r.pattern.test(route));
  renderHeader();
  if (!match) {
    appEl.innerHTML = `<div class="empty-state">Page not found.</div>`;
    return;
  }
  if (match.auth && !state.user) {
    appEl.innerHTML = `<div class="empty-state">Log in to view this page.<br><br><a class="btn primary" href="#/login">Log in / Sign up</a></div>`;
    return;
  }
  if (match.admin && !(state.user && state.user.is_admin)) {
    appEl.innerHTML = `<div class="empty-state">Admin access required.</div>`;
    return;
  }
  const params = match.pattern.exec(route).slice(1);
  try {
    await match.handler(...params);
  } catch (e) {
    appEl.innerHTML = `<div class="card"><p class="error-text">${escapeHtml(e.message)}</p></div>`;
  }
}

window.addEventListener('hashchange', () => navigate());

// ---------- markets list ----------

async function renderMarketsList() {
  appEl.innerHTML = `<h1>Markets</h1><p class="muted">Play-money event contracts — trade YES/NO shares that settle at $1 or $0 when the market resolves.</p><div id="markets-list" class="market-list">Loading…</div>`;
  const markets = await api('/api/markets', { auth: false });
  const listEl = document.getElementById('markets-list');
  if (markets.length === 0) {
    listEl.innerHTML = `<div class="empty-state">No markets yet.${state.user && state.user.is_admin ? ' <a href="#/admin">Create one</a>.' : ''}</div>`;
    return;
  }
  listEl.innerHTML = markets.map(m => `
    <a class="card market-row" href="#/market/${m.id}">
      <div>
        <div class="market-q">${escapeHtml(m.question)}</div>
        <div class="market-meta">${escapeHtml(m.category)} · ${m.status === 'resolved' ? `<span class="tag resolved">Resolved ${m.resolved_outcome}</span>` : 'Open'}</div>
      </div>
      <div class="price-badge yes">${fmtPct(m.price_yes)}<div class="market-meta" style="text-align:right">YES</div></div>
    </a>
  `).join('');
}

// ---------- market detail ----------

async function renderMarketDetail(idStr) {
  const id = Number(idStr);
  appEl.innerHTML = `<div id="market-detail">Loading…</div>`;
  const m = await api(`/api/markets/${id}`, { auth: false });

  const isOpen = m.status === 'open';
  appEl.innerHTML = `
    <div class="market-meta"><a href="#/markets">&larr; All markets</a></div>
    <h1>${escapeHtml(m.question)}</h1>
    <p class="muted">${escapeHtml(m.category)} · ${isOpen ? 'Open' : `Resolved: ${m.resolved_outcome}`}</p>
    ${m.description ? `<p class="muted">${escapeHtml(m.description)}</p>` : ''}
    <div class="detail-grid">
      <div>
        <div class="card">
          <h2>YES price history</h2>
          <div id="chart-wrap" style="position:relative;"></div>
        </div>
        ${m.description ? '' : ''}
      </div>
      <div>
        <div class="card trade-widget">
          <h2>Trade</h2>
          <div id="trade-area"></div>
        </div>
      </div>
    </div>
  `;

  renderPriceChart(document.getElementById('chart-wrap'), m.price_history, m.price_yes);
  renderTradeWidget(document.getElementById('trade-area'), m);
}

function renderTradeWidget(container, market) {
  if (market.status !== 'open') {
    container.innerHTML = `<p class="muted">This market is resolved. Outcome: <strong>${market.resolved_outcome}</strong>. Winning shares paid $1 each; losing shares paid $0.</p>`;
    return;
  }
  if (!state.user) {
    container.innerHTML = `<p class="muted">Log in to trade.</p><a class="btn primary" href="#/login">Log in / Sign up</a>`;
    return;
  }

  let selected = 'YES';
  container.innerHTML = `
    <div class="outcome-toggle">
      <button id="pick-yes" class="selected yes">YES ${fmtPct(market.price_yes)}</button>
      <button id="pick-no">NO ${fmtPct(1 - market.price_yes)}</button>
    </div>
    <label for="shares-input">Shares to buy</label>
    <input type="number" id="shares-input" min="0.01" step="0.01" value="10" />
    <div class="trade-summary" id="trade-preview">Estimated cost: —</div>
    <div class="error-text" id="trade-error" style="display:none;"></div>
    <div class="success-text" id="trade-success" style="display:none;"></div>
    <button class="primary" id="submit-trade" style="width:100%;margin-top:12px;">Buy shares</button>
    <p class="muted" style="margin-top:14px;">Balance: <span id="live-balance">${fmtMoney(state.user.balance)}</span></p>
  `;

  const pickYes = document.getElementById('pick-yes');
  const pickNo = document.getElementById('pick-no');
  const sharesInput = document.getElementById('shares-input');
  const preview = document.getElementById('trade-preview');
  const errorEl = document.getElementById('trade-error');
  const successEl = document.getElementById('trade-success');

  function selectOutcome(o) {
    selected = o;
    pickYes.classList.toggle('selected', o === 'YES');
    pickNo.classList.toggle('selected', o === 'NO');
    updatePreview();
  }
  function updatePreview() {
    const shares = parseFloat(sharesInput.value) || 0;
    const price = selected === 'YES' ? market.price_yes : (1 - market.price_yes);
    const approxCost = shares * price; // rough estimate; actual AMM cost may differ slightly
    preview.textContent = `Approx. cost: ${fmtMoney(approxCost)} for ${shares} ${selected} shares (pays ${fmtMoney(shares)} if correct, $0 if not)`;
  }
  pickYes.onclick = () => selectOutcome('YES');
  pickNo.onclick = () => selectOutcome('NO');
  sharesInput.oninput = updatePreview;
  updatePreview();

  document.getElementById('submit-trade').onclick = async () => {
    errorEl.style.display = 'none';
    successEl.style.display = 'none';
    const shares = parseFloat(sharesInput.value);
    if (!shares || shares <= 0) {
      errorEl.textContent = 'Enter a positive number of shares.';
      errorEl.style.display = 'block';
      return;
    }
    try {
      const result = await api(`/api/markets/${market.id}/trade`, {
        method: 'POST',
        body: { outcome: selected, shares },
      });
      state.user.balance = result.balance;
      document.getElementById('live-balance').textContent = fmtMoney(result.balance);
      successEl.textContent = `Bought ${shares} ${selected} shares for ${fmtMoney(result.cost)}. New price: ${fmtPct(result.price_yes)} YES.`;
      successEl.style.display = 'block';
      renderHeader();

      // Update in place (don't wipe the success message with a full re-render):
      market.price_yes = result.price_yes;
      pickYes.textContent = `YES ${fmtPct(market.price_yes)}`;
      pickNo.textContent = `NO ${fmtPct(1 - market.price_yes)}`;
      updatePreview();
      const fresh = await api(`/api/markets/${market.id}`, { auth: false });
      const chartWrap = document.getElementById('chart-wrap');
      if (chartWrap) renderPriceChart(chartWrap, fresh.price_history, fresh.price_yes);
    } catch (e) {
      errorEl.textContent = e.message;
      errorEl.style.display = 'block';
    }
  };
}

// ---------- hand-rolled SVG price chart (no external chart library) ----------

function renderPriceChart(container, history, currentPrice) {
  const points = (history && history.length > 0) ? history : [{ t: new Date().toISOString(), price: currentPrice }];
  const w = container.clientWidth > 0 ? container.clientWidth : 560;
  const h = 220;
  const padL = 36, padR = 12, padT = 16, padB = 26;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;

  const xForIndex = (i) => padL + (points.length === 1 ? plotW / 2 : (i / (points.length - 1)) * plotW);
  const yForPrice = (p) => padT + (1 - p) * plotH;

  const gridLines = [0, 0.25, 0.5, 0.75, 1].map(p => {
    const y = yForPrice(p);
    return `<line x1="${padL}" y1="${y}" x2="${w - padR}" y2="${y}" stroke="var(--gridline)" stroke-width="1"/>
            <text x="${padL - 8}" y="${y + 4}" font-size="10" fill="var(--text-muted)" text-anchor="end">${Math.round(p * 100)}%</text>`;
  }).join('');

  const path = points.map((pt, i) => `${i === 0 ? 'M' : 'L'} ${xForIndex(i).toFixed(1)} ${yForPrice(pt.price).toFixed(1)}`).join(' ');

  const svg = `
    <svg viewBox="0 0 ${w} ${h}" width="100%" height="${h}" role="img" aria-label="YES price history chart">
      ${gridLines}
      <line x1="${padL}" y1="${padT + plotH}" x2="${w - padR}" y2="${padT + plotH}" stroke="var(--baseline)" stroke-width="1"/>
      <path d="${path}" fill="none" stroke="var(--series-1)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      <circle id="chart-hover-dot" cx="0" cy="0" r="4" fill="var(--series-1)" style="display:none;"/>
      <line id="chart-hover-line" x1="0" y1="${padT}" x2="0" y2="${padT + plotH}" stroke="var(--baseline)" stroke-width="1" style="display:none;"/>
      <rect id="chart-hover-target" x="${padL}" y="${padT}" width="${plotW}" height="${plotH}" fill="transparent" />
    </svg>
    <div id="chart-tooltip" class="chart-tooltip" style="display:none;"></div>
  `;
  container.innerHTML = svg;

  const svgEl = container.querySelector('svg');
  const dot = document.getElementById('chart-hover-dot');
  const line = document.getElementById('chart-hover-line');
  const tooltip = document.getElementById('chart-tooltip');
  const target = document.getElementById('chart-hover-target');

  target.addEventListener('mousemove', (evt) => {
    const rect = svgEl.getBoundingClientRect();
    const scaleX = w / rect.width;
    const mouseX = (evt.clientX - rect.left) * scaleX;
    let nearest = 0, nearestDist = Infinity;
    points.forEach((pt, i) => {
      const dist = Math.abs(xForIndex(i) - mouseX);
      if (dist < nearestDist) { nearestDist = dist; nearest = i; }
    });
    const pt = points[nearest];
    const x = xForIndex(nearest), y = yForPrice(pt.price);
    dot.setAttribute('cx', x); dot.setAttribute('cy', y); dot.style.display = 'block';
    line.setAttribute('x1', x); line.setAttribute('x2', x); line.style.display = 'block';
    const scale = rect.width / w;
    tooltip.style.left = (x * scale) + 'px';
    tooltip.style.top = (y * scale) + 'px';
    tooltip.style.display = 'block';
    tooltip.innerHTML = `<strong>${fmtPct(pt.price)}</strong> YES<br><span style="color:var(--text-muted)">${fmtTime(pt.t)}</span>`;
  });
  target.addEventListener('mouseleave', () => {
    dot.style.display = 'none'; line.style.display = 'none'; tooltip.style.display = 'none';
  });
}

// ---------- portfolio ----------

async function renderPortfolio() {
  appEl.innerHTML = `<h1>Portfolio</h1><div id="portfolio-body">Loading…</div>`;
  const positions = await api('/api/portfolio');
  const body = document.getElementById('portfolio-body');
  body.innerHTML = `<p class="muted">Cash balance: <strong>${fmtMoney(state.user.balance)}</strong></p>`;

  if (positions.length === 0) {
    body.innerHTML += `<div class="empty-state">No open positions yet. <a href="#/markets">Browse markets</a>.</div>`;
    return;
  }
  body.innerHTML += `
    <div class="card">
      <table>
        <thead><tr><th>Market</th><th>Status</th><th class="num">YES shares</th><th class="num">NO shares</th><th class="num">Current YES price</th></tr></thead>
        <tbody>
          ${positions.map(p => `
            <tr>
              <td><a href="#/market/${p.market_id}">${escapeHtml(p.question)}</a></td>
              <td>${p.status === 'resolved' ? `Resolved ${p.resolved_outcome}` : 'Open'}</td>
              <td class="num">${p.shares_yes.toFixed(2)}</td>
              <td class="num">${p.shares_no.toFixed(2)}</td>
              <td class="num">${fmtPct(p.price_yes)}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}

// ---------- admin ----------

async function renderAdmin() {
  appEl.innerHTML = `
    <h1>Admin</h1>
    <div class="card">
      <h2>Create market</h2>
      <form id="create-market-form">
        <label for="q">Question</label>
        <input type="text" id="q" placeholder="Will X happen by Y date?" required />
        <label for="desc">Description (optional)</label>
        <textarea id="desc" rows="2"></textarea>
        <label for="cat">Category</label>
        <input type="text" id="cat" value="General" />
        <label for="liq">Liquidity parameter (b) — higher = deeper liquidity, less price movement per trade</label>
        <input type="number" id="liq" value="100" min="1" />
        <div class="error-text" id="create-error" style="display:none;"></div>
        <button class="primary" type="submit" style="margin-top:12px;">Create market</button>
      </form>
    </div>
    <div class="card">
      <h2>Resolve an open market</h2>
      <div id="resolve-list">Loading…</div>
    </div>
  `;

  document.getElementById('create-market-form').onsubmit = async (e) => {
    e.preventDefault();
    const errorEl = document.getElementById('create-error');
    errorEl.style.display = 'none';
    try {
      await api('/api/markets', {
        method: 'POST',
        body: {
          question: document.getElementById('q').value,
          description: document.getElementById('desc').value,
          category: document.getElementById('cat').value,
          liquidity_b: parseFloat(document.getElementById('liq').value),
        },
      });
      renderAdmin();
    } catch (err) {
      errorEl.textContent = err.message;
      errorEl.style.display = 'block';
    }
  };

  const markets = await api('/api/markets', { auth: false });
  const open = markets.filter(m => m.status === 'open');
  const listEl = document.getElementById('resolve-list');
  if (open.length === 0) {
    listEl.innerHTML = `<p class="muted">No open markets.</p>`;
    return;
  }
  listEl.innerHTML = open.map(m => `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--gridline);">
      <div>${escapeHtml(m.question)} <span class="muted">(${fmtPct(m.price_yes)} YES)</span></div>
      <div style="display:flex;gap:8px;">
        <button data-id="${m.id}" data-outcome="YES" class="resolve-btn">Resolve YES</button>
        <button data-id="${m.id}" data-outcome="NO" class="resolve-btn danger">Resolve NO</button>
      </div>
    </div>
  `).join('');

  listEl.querySelectorAll('.resolve-btn').forEach(btn => {
    btn.onclick = async () => {
      if (!confirm(`Resolve market #${btn.dataset.id} as ${btn.dataset.outcome}? This pays out all holders and cannot be undone.`)) return;
      try {
        await api(`/api/markets/${btn.dataset.id}/resolve`, {
          method: 'POST',
          body: { outcome: btn.dataset.outcome },
        });
        renderAdmin();
      } catch (e) {
        alert(e.message);
      }
    };
  });
}

// ---------- login / signup ----------

function renderLogin() {
  appEl.innerHTML = `
    <form class="auth-form card" id="auth-form">
      <h1 id="auth-title">Log in</h1>
      <label for="username">Username</label>
      <input type="text" id="username" required />
      <label for="password">Password</label>
      <input type="password" id="password" required minlength="6" />
      <div class="error-text" id="auth-error" style="display:none;"></div>
      <button class="primary" type="submit" style="width:100%;margin-top:14px;">Log in</button>
      <p style="margin-top:14px;font-size:13px;">
        <span id="auth-switch-text">Don't have an account?</span>
        <button type="button" class="link-btn" id="auth-switch-btn">Sign up</button>
      </p>
    </form>
  `;
  let mode = 'login';
  const title = document.getElementById('auth-title');
  const switchText = document.getElementById('auth-switch-text');
  const switchBtn = document.getElementById('auth-switch-btn');
  const submitBtn = document.querySelector('#auth-form button.primary');
  const errorEl = document.getElementById('auth-error');

  switchBtn.onclick = () => {
    mode = mode === 'login' ? 'signup' : 'login';
    title.textContent = mode === 'login' ? 'Log in' : 'Sign up';
    submitBtn.textContent = mode === 'login' ? 'Log in' : 'Sign up (get 10,000 play dollars)';
    switchText.textContent = mode === 'login' ? "Don't have an account?" : 'Already have an account?';
    switchBtn.textContent = mode === 'login' ? 'Sign up' : 'Log in';
  };

  document.getElementById('auth-form').onsubmit = async (e) => {
    e.preventDefault();
    errorEl.style.display = 'none';
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    try {
      const result = await api(mode === 'login' ? '/api/login' : '/api/signup', {
        method: 'POST', auth: false,
        body: { username, password },
      });
      state.token = result.token;
      localStorage.setItem('pm_token', result.token);
      state.user = { username: result.username, balance: result.balance, is_admin: result.is_admin };
      navigate('#/markets');
    } catch (err) {
      errorEl.textContent = err.message;
      errorEl.style.display = 'block';
    }
  };
}

// ---------- boot ----------

(async function boot() {
  await refreshMe();
  renderHeader();
  navigate();
})();
