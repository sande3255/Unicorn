# PredictMarket (play-money demo)

A working prediction-market application in the style of Kalshi/Polymarket:
users trade YES/NO shares on event outcomes, prices move automatically via
an AMM, and markets settle for $1 (winning side) or $0 (losing side) when
an admin resolves them.

**This runs entirely on play money. There is no payment processor, no real
currency, and no connection to any bank or wallet.** Read "Before this can
take real money" below before you even think about changing that.

## What's included

- `backend/` — a Flask + SQLite API (Python standard library only, plus
  Flask — no other third-party dependencies). Implements:
  - Signup/login with hashed passwords and session tokens
  - A Logarithmic Market Scoring Rule (LMSR) automated market maker — the
    same style of pricing mechanism real prediction/forecasting markets use,
    so prices move up/down automatically as people trade
  - Market creation and resolution (admin only)
  - Portfolio and trade history per user
- `frontend/` — a single-page app in plain HTML/CSS/JS. No build step, no
  npm, no external CDN dependencies — open it and it works. Markets list,
  market detail with a live price chart, a trade widget, portfolio, and an
  admin panel.

## Running it locally

Requires Python 3.9+ and pip.

```bash
cd backend
pip install -r requirements.txt   # just Flask
python3 run.py
```

Then open **http://localhost:8000** — the Flask server serves both the API
and the frontend, so there's nothing else to start.

A default admin account is created automatically on first run:

- username: `admin`
- password: `admin123`

**Change this password (or the seeding logic in `app/server.py`'s
`seed_admin()`) before showing this to anyone else.** Log in as admin to
create markets from the Admin page; any account can sign up and trade (new
signups start with $10,000 in play money).

The database is a single SQLite file (`backend/predictmarket.db`), created
automatically. Delete it to reset all data.

## How the pricing works

Each market has a liquidity parameter `b`. Buying shares of an outcome
moves that outcome's price up (and the other side's price down by the same
amount, since they sum to 100%); selling moves it back down. Higher `b`
means deeper liquidity — prices move less per trade, but the market itself
can lose more in the worst case (bounded by `b × ln 2`). This is set per
market when an admin creates it.

## Before this can take real money

This app is a working *mechanism*, not a licensed business. Kalshi and
Polymarket US are legal only because they operate as CFTC-regulated
exchanges. Taking real bets on real-world events without that is operating
an unregistered derivatives exchange (or illegal bookmaking, depending on
structure) — a real legal problem regardless of code quality. Before
connecting real money, at minimum you'd need:

- **Regulatory registration** — CFTC registration as a Designated Contract
  Market (or a similar path in your jurisdiction), or a white-label
  partnership with an already-licensed exchange. This is the big one and
  should come before any of the items below.
- **KYC/AML** — identity verification and anti-money-laundering checks on
  every user before they can deposit or withdraw real funds.
- **A real payment processor** — one willing to work with a regulated
  derivatives/prediction-market business; most general processors won't.
- **Geofencing / eligibility checks** — certain states currently restrict or
  litigate against prediction markets (particularly sports-related
  contracts); you'd need to block ineligible users by jurisdiction and keep
  that list current.
- **Custody and solvency controls** — segregating user funds, proving the
  house can always cover its LMSR exposure, audited reserves.
- **Legal counsel** — genuinely, before launch, not after.

None of that is implemented here, on purpose. Treat this as the product/UX
layer to build once the legal and financial infrastructure underneath it
actually exists.

## Known limitations of the demo

- Session tokens don't expire and there's no rate limiting — fine for a
  local demo, not fine for anything public-facing.
- No password reset flow.
- The dev server (`python3 run.py`) is Flask's built-in development
  server — swap in a production WSGI server (gunicorn, waitress) if you
  ever deploy this anywhere reachable by others.
